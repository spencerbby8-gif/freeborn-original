"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AppShell } from "@/components/app/app-shell";
import { openVerifyFlow } from "@/components/app/verify-modal";
import { VerifyBadge } from "@/components/verify-badge";
import { ProfileView } from "@/components/app/profile-view";
import { getAccessToken } from "@/lib/supabase/browser";

type MeProfile = {
  displayName: string;
  age: number | null;
  gender: string;
  city: string;
  region: string;
  bio: string;
  occupation: string;
  education: string;
  language: string;
  religion: string;
  maritalStatus: string;
  hasKids: string;
  wantsKids: string;
  drinking: string;
  smoking: string;
  educationLevel: string;
  heightCmProfile: number | null;
  vaccinationStatus: string;
  values: string[];
  interests: string[];
  lifestyle: string[];
  relationshipGoals: string[];
  photos: string[];
  isVerified: boolean;
};

const LANGUAGES = ["English", "Spanish", "French", "German", "Portuguese", "Arabic", "Mandarin", "Other"];
const RELIGIONS = ["Christian", "Spiritual", "Catholic", "Protestant", "Jewish", "Muslim", "Buddhist", "Hindu", "Agnostic", "Atheist", "Prefer not to say"];
const MARITAL = ["Never married", "Divorced", "Widowed", "Separated", "It's complicated"];
const KIDS = ["No kids", "Have kids", "Kids grown", "Prefer not to say"];
const WANTS_KIDS = ["Want kids", "Not sure", "Don't want kids", "Already have enough"];
const FREQUENCY = ["Never", "Rarely", "Socially", "Regularly"];
const EDUCATION_LEVELS = ["High school", "Trade school", "Some college", "Bachelor's", "Master's", "Doctorate", "Self-taught"];
const VAX = ["prefer_not_to_say", "unvaccinated", "vaccinated"];
const VAX_LABELS: Record<string, string> = {
  prefer_not_to_say: "Prefer not to say",
  unvaccinated: "Unvaccinated",
  vaccinated: "Vaccinated",
};

function SelectField({
  label,
  value,
  options,
  onChange,
  labels,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
  labels?: Record<string, string>;
}) {
  return (
    <div className="space-y-2">
      <span className="text-[12px] font-bold uppercase tracking-wider text-[var(--color-sand)]">{label}</span>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="min-h-[48px] w-full appearance-none rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 pr-10 text-[14px] font-medium text-[var(--color-pearl)] outline-none transition focus:border-[var(--color-gold-500)]"
        >
          <option value="" className="bg-[var(--color-midnight)]">Select…</option>
          {options.map((o) => (
            <option key={o} value={o} className="bg-[var(--color-midnight)]">
              {labels?.[o] ?? o}
            </option>
          ))}
        </select>
        <svg className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-[var(--color-mist)]" width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden>
          <path d="M2.5 5l4.5 4.5L11.5 5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
    </div>
  );
}

function TextField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div className="space-y-2">
      <span className="text-[12px] font-bold uppercase tracking-wider text-[var(--color-sand)]">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="min-h-[48px] w-full rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-[14px] font-medium text-[var(--color-pearl)] outline-none transition placeholder:text-[var(--color-ash)] focus:border-[var(--color-gold-500)]"
      />
    </div>
  );
}

function ProfileInner() {
  const [profile, setProfile] = useState<(MeProfile & { id?: string }) | null>(null);
  const [completeness, setCompleteness] = useState(0);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<Partial<MeProfile>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [viewAs, setViewAs] = useState<string | null>(null);
  const [photoMsg, setPhotoMsg] = useState<string | null>(null);
  const [pendingPhoto, setPendingPhoto] = useState<string | null>(null);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [photoManagerOpen, setPhotoManagerOpen] = useState(false);
  const photoInputRef = useRef<HTMLInputElement | null>(null);

  const uploadPhoto = useCallback(
    async (dataUrl: string) => {
      setPhotoBusy(true);
      try {
        const token = await getAccessToken().catch(() => null);
        const res = await fetch("/api/profile/photos", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ data: dataUrl }),
        });
        const json = await res.json().catch(() => ({}));
        if (res.ok) {
          setPhotoMsg(
            json.revoked
              ? "Photo added — your teal seal was removed until you re-verify."
              : "Photo added to your profile."
          );
        } else {
          setPhotoMsg(json.error ?? "Couldn't add that photo.");
        }
        setTimeout(() => setPhotoMsg(null), 5000);
      } finally {
        setPhotoBusy(false);
        void load(); // refresh the verified/re-verify banner immediately
      }
    },
    []
  );

  const deletePhoto = useCallback(async (path: string) => {
    const token = await getAccessToken().catch(() => null);
    const res = await fetch("/api/profile/photos", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ path }),
    });
    const json = await res.json().catch(() => ({}));
    setPhotoMsg(res.ok ? "Photo removed." : json.error ?? "Couldn't remove that photo here.");
    setTimeout(() => setPhotoMsg(null), 5000);
  }, []);

  const onPhotoPicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result);
      if (profile?.isVerified) {
        setPendingPhoto(dataUrl); // warn before touching the badge
      } else {
        void uploadPhoto(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const load = useCallback(async () => {
    const token = await getAccessToken().catch(() => null);
    const res = await fetch("/api/profile/me", { headers: token ? { Authorization: `Bearer ${token}` } : {} });
    if (res.ok) {
      const json = await res.json();
      setProfile(json.profile);
      setCompleteness(json.completeness);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const startEdit = () => {
    if (profile) setDraft({ ...profile });
    setEditing(true);
    setSaved(false);
  };

  const save = async () => {
    setSaving(true);
    const token = await getAccessToken().catch(() => null);
    const res = await fetch("/api/profile/me", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(draft),
    });
    setSaving(false);
    if (res.ok) {
      setSaved(true);
      setEditing(false);
      await load();
      setTimeout(() => setSaved(false), 2500);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <span className="inline-block h-9 w-9 animate-spin rounded-full border-2 border-[var(--color-gold-500)] border-t-transparent" />
      </div>
    );
  }

  if (!profile) {
    return <p className="py-20 text-center text-sm text-[var(--color-mist)]">Couldn't load your profile.</p>;
  }

  const set = (patch: Partial<MeProfile>) => setDraft((prev) => ({ ...prev, ...patch }));

  return (
    <div className="mx-auto max-w-[720px] pb-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold tracking-tight sm:text-3xl">Your profile</h1>
          <p className="mt-1.5 text-sm text-[var(--color-mist)]">How others see you in the room.</p>
        </div>
        {!editing ? (
          <div className="flex items-center gap-2">
            {profile?.id ? (
              <button
                type="button"
                onClick={() => setViewAs(profile.id ?? null)}
                className="btn-ghost rounded-full px-5 py-2.5 text-[13px] font-bold"
                title="See exactly what other members see"
              >
                View as others
              </button>
            ) : null}
            <button type="button" onClick={startEdit} className="btn-ghost rounded-full px-5 py-2.5 text-[13px] font-bold">
              Edit profile
            </button>
          </div>
        ) : null}
      </div>

      {/* Identity verification reminder */}
      {profile.isVerified ? (
        <div className="mt-6 flex items-center gap-3 rounded-[22px] border border-[var(--color-teal-500)]/30 bg-[var(--color-teal-500)]/[0.07] p-4">
          <VerifyBadge size={26} />
          <div>
            <p className="text-[14px] font-black text-[var(--color-teal-300)]">Identity verified</p>
            <p className="mt-0.5 text-[12px] leading-4 text-[var(--color-mist)]">
              The teal seal is live on your profile — members know they're talking to the real you.
            </p>
          </div>
        </div>
      ) : (
        <div className="mt-6 flex items-center gap-4 rounded-[22px] border border-[var(--color-gold-500)]/35 bg-[var(--color-gold-500)]/[0.06] p-4">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-[var(--color-gold-500)]/40 bg-[var(--color-gold-500)]/10 text-[var(--color-gold-300)]">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
              <path d="M12 2.5l7.5 3v5.2c0 5-3.2 8.6-7.5 10.3-4.3-1.7-7.5-5.3-7.5-10.3V5.5l7.5-3z" />
              <path d="M8.8 12l2.2 2.2 4.2-4.6" />
            </svg>
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[14px] font-black text-[var(--color-pearl)]">Verify your identity</p>
            <p className="mt-0.5 text-[12px] leading-4 text-[var(--color-mist)]">
              A 20-second selfie check earns the teal seal and keeps the room safe.
            </p>
          </div>
          <button
            type="button"
            onClick={openVerifyFlow}
            className="shrink-0 rounded-full bg-[var(--gradient-ember-warm)] px-4 py-2.5 text-[12px] font-black text-white shadow-[var(--shadow-primary-btn)] transition active:scale-95"
          >
            Verify now
          </button>
        </div>
      )}

      {/* Completion */}
      <div className="mt-6 rounded-[24px] border border-white/[0.07] bg-white/[0.025] p-5">
        <div className="flex items-center justify-between">
          <span className="text-[13px] font-bold uppercase tracking-wider text-[var(--color-sand)]">Profile completion</span>
          <span className="font-display text-xl font-semibold text-[var(--color-gold-300)]">{completeness}%</span>
        </div>
        <div className="mt-3 h-2.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
          <div
            className="h-full rounded-full bg-[var(--gradient-ember-warm)] transition-all duration-700"
            style={{ width: `${completeness}%` }}
          />
        </div>
        <p className="mt-3 text-[12px] leading-5 text-[var(--color-mist)]">
          {completeness >= 80
            ? "Looking strong — complete profiles get far more meaningful matches."
            : "Complete the details below to show up higher in discovery and attract better matches."}
        </p>
      </div>

      {/* Photos + name */}
      <div className="mt-6 flex items-center gap-4">
        {profile.photos[0] ? (
          <img src={profile.photos[0]} alt={profile.displayName} className="h-20 w-20 rounded-full border border-white/10 object-cover" />
        ) : (
          <span className="flex h-20 w-20 items-center justify-center rounded-full bg-[var(--gradient-ember-warm)] font-display text-2xl font-bold text-white">
            {(profile.displayName || "You").charAt(0)}
          </span>
        )}
        <div className="min-w-0 flex-1">
          <p className="font-display text-xl font-semibold text-[var(--color-pearl)]">
            {profile.displayName || "Add your name"}
            {profile.age ? `, ${profile.age}` : ""}
          </p>
          <p className="text-[13px] text-[var(--color-mist)]">
            {[profile.city, profile.region].filter(Boolean).join(", ") || "Add your city"}
          </p>
        </div>
        <input
          ref={photoInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="hidden"
          onChange={onPhotoPicked}
        />
        <button
          type="button"
          disabled={photoBusy}
          onClick={() => setPhotoManagerOpen(true)}
          className="shrink-0 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2.5 text-[12px] font-bold text-[var(--color-sand)] transition hover:bg-white/[0.09] hover:text-[var(--color-pearl)] disabled:opacity-50"
        >
          Add more photos
        </button>
      </div>

      {/* Photo manager — onboarding-style grid */}
      {photoManagerOpen ? (
        <div className="fixed inset-0 z-[140] flex items-end justify-center bg-black/70 p-4 backdrop-blur-sm sm:items-center" role="dialog" aria-modal="true" aria-label="Manage photos">
          <div className="animate-scale-in w-full max-w-[440px] rounded-[28px] border border-white/[0.09] bg-[#0c101d] p-5 shadow-[0_50px_120px_-24px_rgba(0,0,0,0.95)]">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-display text-[19px] font-semibold text-[var(--color-pearl)]">Your photos</p>
                <p className="mt-0.5 text-[12px] text-[var(--color-mist)]">
                  {profile.photos.length}/6 slots · first photo is your card photo
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPhotoManagerOpen(false)}
                aria-label="Close photo manager"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/[0.06] text-[var(--color-mist)] transition hover:bg-white/[0.12] hover:text-[var(--color-pearl)]"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden>
                  <path d="M6 6l12 12M18 6L6 18" />
                </svg>
              </button>
            </div>

            <div className="mt-4 grid grid-cols-3 gap-2.5">
              {profile.photos.map((src, i) => (
                <div key={`${src}-${i}`} className="relative">
                  <img src={src} alt={`Profile photo ${i + 1}`} className="aspect-[3/4] w-full rounded-2xl border border-white/10 object-cover" />
                  {i === 0 ? (
                    <span className="absolute left-1.5 top-1.5 rounded-md bg-[var(--color-gold-500)]/90 px-1.5 py-px text-[8.5px] font-black uppercase tracking-wider text-black">
                      Card
                    </span>
                  ) : null}
                  <button
                    type="button"
                    onClick={() => void deletePhoto(src)}
                    aria-label={`Remove photo ${i + 1}`}
                    className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-black/75 text-white ring-1 ring-white/25 transition hover:bg-black"
                  >
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" aria-hidden>
                      <path d="M6 6l12 12M18 6L6 18" />
                    </svg>
                  </button>
                </div>
              ))}
              {profile.photos.length < 6 ? (
                <button
                  type="button"
                  disabled={photoBusy}
                  onClick={() => photoInputRef.current?.click()}
                  className="flex aspect-[3/4] w-full flex-col items-center justify-center gap-1.5 rounded-2xl border-2 border-dashed border-[var(--color-gold-500)]/40 bg-[var(--color-gold-500)]/[0.05] text-[var(--color-gold-300)] transition hover:bg-[var(--color-gold-500)]/[0.1] disabled:opacity-50"
                >
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
                    <path d="M12 5v14M5 12h14" />
                  </svg>
                  <span className="text-[10.5px] font-black uppercase tracking-wider">
                    {photoBusy ? "Adding…" : "Add"}
                  </span>
                </button>
              ) : null}
            </div>

            <p className="mt-4 rounded-xl border border-[var(--color-gold-500)]/25 bg-[var(--color-gold-500)]/[0.06] px-3.5 py-2.5 text-[11.5px] leading-4 text-[var(--color-gold-300)]">
              Adding a new photo removes your teal seal until you re-verify — that's how
              members know the badge always matches the face.
            </p>
          </div>
        </div>
      ) : null}

      {photoMsg ? (
        <p className="mt-3 rounded-xl border border-white/[0.08] bg-white/[0.04] px-4 py-2.5 text-[12.5px] font-bold text-[var(--color-sand)]">
          {photoMsg}
        </p>
      ) : null}

      {/* New-photo warning: the teal seal is tied to your current photos */}
      {pendingPhoto ? (
        <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" role="dialog" aria-modal="true">
          <div className="animate-scale-in w-full max-w-[400px] rounded-[24px] border border-[var(--color-gold-500)]/30 bg-[#0c101d] p-6 shadow-[0_40px_100px_-20px_rgba(0,0,0,0.9)]">
            <div className="flex items-start gap-3">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-[var(--color-gold-500)]/40 bg-[var(--color-gold-500)]/10 text-[var(--color-gold-300)]">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                  <path d="M12 3l9 16H3l9-16z" />
                  <path d="M12 10v4M12 17h.01" />
                </svg>
              </span>
              <div>
                <p className="font-display text-[18px] font-semibold text-[var(--color-pearl)]">
                  New photo, fresh check
                </p>
                <p className="mt-1.5 text-[12.5px] leading-5 text-[var(--color-mist)]">
                  Your teal seal verifies the photos currently on your profile. Adding a new
                  photo removes the seal until you re-verify — that's how other members know
                  the badge always matches the face.
                </p>
              </div>
            </div>
            <div className="mt-5 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  const data = pendingPhoto;
                  setPendingPhoto(null);
                  if (data) void uploadPhoto(data);
                }}
                className="flex-1 rounded-full bg-[var(--gradient-ember-warm)] py-3 text-[13px] font-black text-white transition active:scale-[0.98]"
              >
                Add it & re-verify after
              </button>
              <button
                type="button"
                onClick={() => setPendingPhoto(null)}
                className="rounded-full border border-white/10 bg-white/[0.04] px-5 py-3 text-[13px] font-bold text-[var(--color-mist)] transition hover:text-[var(--color-pearl)]"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {viewAs ? <ProfileView profileId={viewAs} onClose={() => setViewAs(null)} /> : null}

      {!editing ? (
        <div className="mt-6 space-y-4">
          {profile.bio ? (
            <div className="rounded-[20px] border border-white/[0.07] bg-white/[0.025] p-4">
              <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[var(--color-gold-500)]">About me</p>
              <p className="mt-2 text-[14px] leading-relaxed text-[var(--color-ivory)]">{profile.bio}</p>
            </div>
          ) : null}

          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Occupation", value: profile.occupation },
              { label: "Education", value: profile.educationLevel || profile.education },
              { label: "Language", value: profile.language },
              { label: "Religion", value: profile.religion },
              { label: "Marital status", value: profile.maritalStatus },
              { label: "Kids", value: profile.hasKids },
              { label: "Wants kids", value: profile.wantsKids },
              { label: "Drinking", value: profile.drinking },
              { label: "Smoking", value: profile.smoking },
              { label: "Height", value: profile.heightCmProfile ? `${profile.heightCmProfile} cm` : "" },
              { label: "Vaccination", value: VAX_LABELS[profile.vaccinationStatus] },
            ]
              .filter((f) => f.value)
              .map((f) => (
                <div key={f.label} className="rounded-[16px] border border-white/[0.06] bg-white/[0.02] p-3.5">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[var(--color-ash)]">{f.label}</p>
                  <p className="mt-1 text-[13px] font-semibold text-[var(--color-ivory)]">{f.value}</p>
                </div>
              ))}
          </div>

          {profile.values.length || profile.interests.length || profile.lifestyle.length ? (
            <div className="space-y-3">
              {profile.values.length ? (
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[var(--color-gold-500)]">Values</p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {profile.values.map((v) => (
                      <span key={v} className="rounded-full border border-white/[0.07] bg-pearl/5 px-3 py-1 text-[11px] font-semibold text-sand">{v}</span>
                    ))}
                  </div>
                </div>
              ) : null}
              {profile.interests.length ? (
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[var(--color-gold-500)]">Interests</p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {profile.interests.map((v) => (
                      <span key={v} className="rounded-full border border-white/[0.07] bg-pearl/5 px-3 py-1 text-[11px] font-semibold text-sand">{v}</span>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          ) : null}
        </div>
      ) : (
        <div className="mt-6 space-y-5">
          <div className="rounded-[24px] border border-white/[0.07] bg-white/[0.025] p-5">
            <p className="mb-4 text-[13px] font-bold uppercase tracking-wider text-[var(--color-sand)]">Basics</p>
            <div className="grid gap-4 sm:grid-cols-2">
              <TextField label="Display name" value={draft.displayName ?? ""} onChange={(v) => set({ displayName: v })} placeholder="Your name" />
              <TextField label="City" value={draft.city ?? ""} onChange={(v) => set({ city: v })} placeholder="City" />
              <TextField label="Occupation" value={draft.occupation ?? ""} onChange={(v) => set({ occupation: v })} placeholder="What you do" />
              <TextField label="Height (cm)" value={draft.heightCmProfile ? String(draft.heightCmProfile) : ""} onChange={(v) => set({ heightCmProfile: Number(v) || null })} placeholder="e.g. 175" />
            </div>
            <div className="mt-4 space-y-2">
              <span className="text-[12px] font-bold uppercase tracking-wider text-[var(--color-sand)]">About me</span>
              <textarea
                value={draft.bio ?? ""}
                onChange={(e) => set({ bio: e.target.value })}
                placeholder="A short, honest intro…"
                className="min-h-[110px] w-full resize-none rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-[14px] leading-relaxed text-[var(--color-pearl)] outline-none transition placeholder:text-[var(--color-ash)] focus:border-[var(--color-gold-500)]"
              />
            </div>
          </div>

          <div className="rounded-[24px] border border-white/[0.07] bg-white/[0.025] p-5">
            <p className="mb-4 text-[13px] font-bold uppercase tracking-wider text-[var(--color-sand)]">Background & lifestyle</p>
            <div className="grid gap-4 sm:grid-cols-2">
              <SelectField label="Language" value={draft.language ?? ""} options={LANGUAGES} onChange={(v) => set({ language: v })} />
              <SelectField label="Religion" value={draft.religion ?? ""} options={RELIGIONS} onChange={(v) => set({ religion: v })} />
              <SelectField label="Marital status" value={draft.maritalStatus ?? ""} options={MARITAL} onChange={(v) => set({ maritalStatus: v })} />
              <SelectField label="Education level" value={draft.educationLevel ?? ""} options={EDUCATION_LEVELS} onChange={(v) => set({ educationLevel: v })} />
              <SelectField label="Have kids?" value={draft.hasKids ?? ""} options={KIDS} onChange={(v) => set({ hasKids: v })} />
              <SelectField label="Want kids?" value={draft.wantsKids ?? ""} options={WANTS_KIDS} onChange={(v) => set({ wantsKids: v })} />
              <SelectField label="Drinking" value={draft.drinking ?? ""} options={FREQUENCY} onChange={(v) => set({ drinking: v })} />
              <SelectField label="Smoking" value={draft.smoking ?? ""} options={FREQUENCY} onChange={(v) => set({ smoking: v })} />
              <SelectField label="Vaccination stance" value={draft.vaccinationStatus ?? ""} options={VAX} labels={VAX_LABELS} onChange={(v) => set({ vaccinationStatus: v })} />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button type="button" onClick={() => void save()} disabled={saving} className="btn-ember btn-shine relative flex-1 overflow-hidden rounded-full px-6 py-3.5 text-[15px] font-bold disabled:opacity-60">
              {saving ? "Saving…" : "Save changes"}
            </button>
            <button type="button" onClick={() => setEditing(false)} className="btn-ghost rounded-full px-6 py-3.5 text-[14px] font-bold">
              Cancel
            </button>
          </div>
          {saved ? <p className="text-center text-[13px] font-bold text-[var(--color-teal-300)]">✓ Profile saved</p> : null}
        </div>
      )}
    </div>
  );
}

export default function ProfilePage() {
  return (
    <AppShell>
      <ProfileInner />
    </AppShell>
  );
}
