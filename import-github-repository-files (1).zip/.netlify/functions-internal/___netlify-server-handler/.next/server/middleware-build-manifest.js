globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/3secRG6Wyq9gKYFg37QdP/_buildManifest.js",
    "static/3secRG6Wyq9gKYFg37QdP/_ssgManifest.js",
    "static/3secRG6Wyq9gKYFg37QdP/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0bzupvr5gt3k9.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/0x~d-uw7zrjqi.js",
    "static/chunks/turbopack-0j_ad_~wxace0.js"
  ]
};
